import os

class Config:
    SECRET_KEY = os.getenv('SECRET_KEY', 'ddf3912a425cf848c2a3349657c42fa6bf28cca97dd121cb')
    SQLALCHEMY_DATABASE_URI = 'sqlite:///events.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
